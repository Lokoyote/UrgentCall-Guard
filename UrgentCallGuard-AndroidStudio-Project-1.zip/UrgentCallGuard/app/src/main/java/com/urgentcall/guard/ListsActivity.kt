package com.urgentcall.guard

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.tabs.TabLayout

/**
 * Écran unique avec deux onglets : Liste blanche et Liste noire.
 * Fusionne l'ancienne WhitelistActivity et l'ancienne BlacklistActivity.
 */
class ListsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INITIAL_TAB = "initial_tab"
        const val TAB_WHITELIST = 0
        const val TAB_BLACKLIST = 1
        const val TAB_RESOURCES = 2
    }

    // --- Liste blanche ---
    private lateinit var whitelistTabContent: View
    private lateinit var whitelistRecyclerView: RecyclerView
    private lateinit var whitelistEmptyText: TextView
    private lateinit var whitelistAdapter: WhitelistAdapter
    private lateinit var systemFavoritesSwitch: Switch

    // --- Liste noire ---
    private lateinit var blacklistTabContent: View
    private lateinit var blacklistRecyclerView: RecyclerView
    private lateinit var blacklistEmptyText: TextView
    private lateinit var blacklistAdapter: BlacklistAdapter
    private lateinit var blockHiddenSwitch: Switch
    private lateinit var blockUnknownSwitch: Switch

    // --- Ressources (autres bloqueurs libres) ---
    private lateinit var resourcesTabContent: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lists)
        title = getString(R.string.lists_title)

        setupWhitelistTab()
        setupBlacklistTab()
        setupResourcesTab()

        val tabLayout = findViewById<TabLayout>(R.id.listsTabLayout)
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = showTab(tab.position)
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        val initialTab = intent.getIntExtra(EXTRA_INITIAL_TAB, TAB_WHITELIST)
        tabLayout.getTabAt(initialTab)?.select()
        showTab(initialTab)
    }

    override fun onResume() {
        super.onResume()
        // Rafraîchit au retour de l'écran "Ajouter depuis les contacts"
        // (qui peut avoir ajouté à la liste blanche ou à la liste noire),
        // et resynchronise les favoris système (changés côté téléphone, ou
        // permission Contacts accordée entretemps).
        WhitelistHelper.syncSystemFavorites(this)
        refreshWhitelist()
        refreshBlacklist()
    }

    private fun showTab(position: Int) {
        whitelistTabContent.visibility = if (position == TAB_WHITELIST) View.VISIBLE else View.GONE
        blacklistTabContent.visibility = if (position == TAB_BLACKLIST) View.VISIBLE else View.GONE
        resourcesTabContent.visibility = if (position == TAB_RESOURCES) View.VISIBLE else View.GONE
    }

    // ----------------------- Liste blanche -----------------------

    private fun setupWhitelistTab() {
        whitelistTabContent = findViewById(R.id.whitelistTabContent)
        whitelistRecyclerView = findViewById(R.id.whitelistRecyclerView)
        whitelistEmptyText = findViewById(R.id.whitelistEmptyText)
        systemFavoritesSwitch = findViewById(R.id.systemFavoritesSwitch)
        val addButton = findViewById<MaterialButton>(R.id.addContactButton)
        val addFromContactsButton = findViewById<MaterialButton>(R.id.addFromContactsButton)

        systemFavoritesSwitch.isChecked = PreferencesHelper.isAllowSystemFavorites(this)
        systemFavoritesSwitch.setOnCheckedChangeListener { _, checked ->
            PreferencesHelper.setAllowSystemFavorites(this, checked)
            WhitelistHelper.syncSystemFavorites(this)
            refreshWhitelist()
        }

        // Aligne tout de suite la liste blanche sur les favoris actuels du téléphone
        // (utile si l'option était déjà activée et que des favoris ont changé entretemps).
        WhitelistHelper.syncSystemFavorites(this)

        whitelistAdapter = WhitelistAdapter(WhitelistHelper.getContacts(this).toMutableList()) { contact ->
            WhitelistHelper.removeContact(this, contact.phoneNumber)
            refreshWhitelist()
        }
        whitelistRecyclerView.layoutManager = LinearLayoutManager(this)
        whitelistRecyclerView.adapter = whitelistAdapter

        addButton.setOnClickListener { showAddWhitelistDialog() }
        addFromContactsButton.setOnClickListener {
            startActivity(
                Intent(this, AddFromContactsActivity::class.java)
                    .putExtra(AddFromContactsActivity.EXTRA_TARGET, AddFromContactsActivity.TARGET_WHITELIST)
            )
        }
    }

    private fun refreshWhitelist() {
        val contacts = WhitelistHelper.getContacts(this)
        whitelistAdapter.updateData(contacts)
        whitelistEmptyText.visibility = if (contacts.isEmpty()) View.VISIBLE else View.GONE
        whitelistRecyclerView.visibility = if (contacts.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showAddWhitelistDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_contact, null)
        val nameInput = dialogView.findViewById<AutoCompleteTextView>(R.id.dialogNameInput)
        val phoneInput = dialogView.findViewById<EditText>(R.id.dialogPhoneInput)
        setupContactAutocomplete(nameInput, phoneInput)

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.whitelist_add_title)
            .setView(dialogView)
            .setPositiveButton(R.string.whitelist_add_button) { _, _ ->
                val name = nameInput.text.toString().trim()
                val phone = phoneInput.text.toString().trim()
                if (name.isNotEmpty() && phone.isNotEmpty()) {
                    WhitelistHelper.addContact(this, WhitelistContact(name, phone, isPriority = true))
                    refreshWhitelist()
                } else {
                    Toast.makeText(this, R.string.whitelist_add_title, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.whitelist_cancel_button, null)
            .create()
        bindConfirmEnabledOnPhoneFilled(dialog, phoneInput)
        dialog.show()
    }

    private fun setupContactAutocomplete(nameInput: AutoCompleteTextView, phoneInput: EditText) {
        nameInput.setAdapter(ContactAutoCompleteAdapter(this))
        nameInput.threshold = 1
        nameInput.setOnItemClickListener { parent, _, position, _ ->
            val selected = parent.getItemAtPosition(position) as ContactEntry
            nameInput.setText(selected.name)
            phoneInput.setText(selected.phoneNumber)
        }
    }

    // ----------------------- Liste noire -----------------------

    private fun setupBlacklistTab() {
        blacklistTabContent = findViewById(R.id.blacklistTabContent)
        blacklistRecyclerView = findViewById(R.id.blacklistRecyclerView)
        blacklistEmptyText = findViewById(R.id.blacklistEmptyText)
        blockHiddenSwitch = findViewById(R.id.blockHiddenSwitch)
        blockUnknownSwitch = findViewById(R.id.blockUnknownSwitch)
        val addButton = findViewById<MaterialButton>(R.id.blacklistAddButton)
        val addFromContactsButton = findViewById<MaterialButton>(R.id.blacklistAddFromContactsButton)

        blockHiddenSwitch.isChecked = BlacklistHelper.isBlockHiddenNumbers(this)
        blockHiddenSwitch.setOnCheckedChangeListener { _, checked ->
            BlacklistHelper.setBlockHiddenNumbers(this, checked)
        }

        blockUnknownSwitch.isChecked = BlacklistHelper.isBlockUnknownNumbers(this)
        blockUnknownSwitch.setOnCheckedChangeListener { _, checked ->
            BlacklistHelper.setBlockUnknownNumbers(this, checked)
        }

        blacklistAdapter = BlacklistAdapter(BlacklistHelper.getEntries(this).toMutableList()) { entry ->
            BlacklistHelper.removeEntry(this, entry.phoneNumber)
            refreshBlacklist()
        }
        blacklistRecyclerView.layoutManager = LinearLayoutManager(this)
        blacklistRecyclerView.adapter = blacklistAdapter

        addButton.setOnClickListener { showAddBlacklistDialog() }
        addFromContactsButton.setOnClickListener {
            startActivity(
                Intent(this, AddFromContactsActivity::class.java)
                    .putExtra(AddFromContactsActivity.EXTRA_TARGET, AddFromContactsActivity.TARGET_BLACKLIST)
            )
        }

        refreshBlacklist()
    }

    private fun refreshBlacklist() {
        val entries = BlacklistHelper.getEntries(this)
        blacklistAdapter.updateData(entries)
        blacklistEmptyText.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        blacklistRecyclerView.visibility = if (entries.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showAddBlacklistDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_contact, null)
        val nameInput = dialogView.findViewById<AutoCompleteTextView>(R.id.dialogNameInput)
        val phoneInput = dialogView.findViewById<EditText>(R.id.dialogPhoneInput)
        setupContactAutocomplete(nameInput, phoneInput)
        nameInput.hint = getString(R.string.blacklist_label_hint)

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.blacklist_add_title)
            .setView(dialogView)
            .setPositiveButton(R.string.blacklist_add_button) { _, _ ->
                val label = nameInput.text.toString().trim().ifBlank { getString(R.string.blacklist_default_label) }
                val phone = phoneInput.text.toString().trim()
                if (phone.isNotEmpty()) {
                    BlacklistHelper.addEntry(this, BlacklistEntry(label, phone))
                    refreshBlacklist()
                } else {
                    Toast.makeText(this, R.string.whitelist_phone_hint, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.whitelist_cancel_button, null)
            .create()
        bindConfirmEnabledOnPhoneFilled(dialog, phoneInput)
        dialog.show()
    }

    /** Désactive le bouton "Ajouter" tant que le champ numéro est vide. */
    private fun bindConfirmEnabledOnPhoneFilled(dialog: AlertDialog, phoneInput: EditText) {
        dialog.setOnShowListener {
            val confirmButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            confirmButton.isEnabled = phoneInput.text.toString().isNotBlank()
            phoneInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    confirmButton.isEnabled = s?.toString()?.isNotBlank() == true
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
    }

    // ----------------------- Ressources -----------------------

    private fun setupResourcesTab() {
        resourcesTabContent = findViewById(R.id.resourcesTabContent)

        findViewById<MaterialButton>(R.id.saracrocheWebsiteButton).setOnClickListener {
            openUrl(getString(R.string.resource_saracroche_website))
        }
        findViewById<MaterialButton>(R.id.saracrocheFdroidButton).setOnClickListener {
            openUrl(getString(R.string.resource_saracroche_fdroid))
        }
        findViewById<MaterialButton>(R.id.callBlockerFdroidButton).setOnClickListener {
            openUrl(getString(R.string.resource_callblocker_fdroid))
        }
        findViewById<MaterialButton>(R.id.callBlockerSourceButton).setOnClickListener {
            openUrl(getString(R.string.resource_callblocker_source))
        }
        findViewById<MaterialButton>(R.id.wincallsWebsiteButton).setOnClickListener {
            openUrl(getString(R.string.resource_wincalls_website))
        }
        findViewById<MaterialButton>(R.id.wincallsPlayStoreButton).setOnClickListener {
            openUrl(getString(R.string.resource_wincalls_playstore))
        }
        findViewById<MaterialButton>(R.id.fdroidExploreButton).setOnClickListener {
            openUrl(getString(R.string.resource_fdroid_explore_url))
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, url, Toast.LENGTH_LONG).show()
        }
    }
}
